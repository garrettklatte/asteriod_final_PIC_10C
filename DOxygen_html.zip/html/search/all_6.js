var searchData=
[
  ['rotateship',['rotateShip',['../class_main_window.html#a41b39e5122680d50fd4e739915e0b325',1,'MainWindow']]]
];
