var searchData=
[
  ['getlabel',['getLabel',['../class_asteroid.html#a485417d85c3be9ab37cac9ca3cf9b82e',1,'Asteroid']]],
  ['getx',['getX',['../class_asteroid.html#a215e56d55b5baaa30ba2c463e8fb3c0a',1,'Asteroid']]],
  ['getxdir',['getXdir',['../class_asteroid.html#a89cf222dfe2d317ba649242a240e3663',1,'Asteroid']]],
  ['gety',['getY',['../class_asteroid.html#a0b1c9a2b4c0903037da5fd4b296c8a96',1,'Asteroid']]],
  ['getydir',['getYdir',['../class_asteroid.html#a6be0f8f3febb7c2259e599dcb8fc507b',1,'Asteroid']]]
];
